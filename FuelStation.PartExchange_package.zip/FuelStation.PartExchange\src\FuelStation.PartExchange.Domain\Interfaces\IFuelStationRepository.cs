using FuelStation.PartExchange.Domain.Entities;

namespace FuelStation.PartExchange.Domain.Interfaces;

public interface IFuelStationRepository
{
    Task<FuelStation?> GetByIdAsync(Guid id);
    Task<IEnumerable<FuelStation>> GetByCityAsync(string city);
    Task AddAsync(FuelStation station);
}
