using FuelStation.PartExchange.Domain.Interfaces;
using FuelStation.PartExchange.Domain.Entities;

namespace FuelStation.PartExchange.Infrastructure.Services;

public class PartMatchingService : IPartMatchingService
{
    private readonly IFuelStationRepository _stationRepo;
    private readonly IPartInventoryRepository _inventoryRepo;

    public PartMatchingService(IFuelStationRepository stationRepo, IPartInventoryRepository inventoryRepo)
    {
        _stationRepo = stationRepo;
        _inventoryRepo = inventoryRepo;
    }

    public async Task<IEnumerable<(FuelStation Station, StationInventory Inventory)>> FindSuppliersAsync(Guid requestingStationId, string partNumber, int quantity)
    {
        var requesting = await _stationRepo.GetByIdAsync(requestingStationId);
        if (requesting == null) return Enumerable.Empty<(FuelStation, StationInventory)>();

        var candidates = await _inventoryRepo.FindPartInCityAsync(requesting.City, partNumber);
        return candidates.Where(x => x.Inventory.Quantity >= quantity && x.Station.Id != requestingStationId);
    }
}
