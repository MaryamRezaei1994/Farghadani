using FuelStation.PartExchange.Domain.Entities;
using FuelStation.PartExchange.Domain.Interfaces;
using FuelStation.PartExchange.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace FuelStation.PartExchange.Infrastructure.Repositories;

public class FuelStationRepository : IFuelStationRepository
{
    private readonly PartExchangeDbContext _db;

    public FuelStationRepository(PartExchangeDbContext db) => _db = db;

    public async Task AddAsync(FuelStation station)
    {
        await _db.FuelStations.AddAsync(station);
    }

    public Task<FuelStation?> GetByIdAsync(Guid id) => _db.FuelStations.FirstOrDefaultAsync(x => x.Id == id);

    public Task<IEnumerable<FuelStation>> GetByCityAsync(string city) =>
        Task.FromResult<IEnumerable<FuelStation>>(_db.FuelStations.Where(x => x.City == city).AsEnumerable());
}
